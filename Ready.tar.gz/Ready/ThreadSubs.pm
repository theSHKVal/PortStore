#!/usr/bin/perl

package ThreadSubs;

use strict;
use MessageStruct;
use Data::Dumper;
use IO::Socket::INET;
use locale;
use DBConnection;
use POSIX qw/strftime/;

use constant TIMEOUT => 3;
use constant PERIOD_ORDER => 15;
use constant PERIOD_GMASK => 10;
use constant PERIOD_VIDEO => 17;

use constant SUCCESS_CODE => 0xAA;
use constant CMD_ORDER => 0x01;
use constant CMD_GMASK => 0x02;
use constant CMD_VIDEO => 0x03;

sub send_orders
{
	#print "Tread 1 on\n";
	my %config = @_;
	my $err;

	while (1)
	{
		my $sock;
		my $dbconn;
		my $message;

		($sock, $dbconn, $message) = init(%config);
		
		if ($sock && $dbconn)
		{
			while (my @data = $dbconn->get_last_order())
			{
				while (1)
				{
					$message->clear();
					$message->cmd(CMD_ORDER);
					$message->add($data[1]); #name
					$message->add($data[2]); #tel
					$message->add($data[3]); #mail
					$message->add($data[4]); #item
					$message->send();
					if ($err)
					{
						log_err("Failed to send order.\n");
						sleep(TIMEOUT);
						redo;
					}
					$err = $message->recv();
					if (!$err && $message->cmd() == SUCCESS_CODE) 
					{
						$dbconn->clear_last_order();
						last;
					}
					else
					{
						log_err("The order has been sent, but server failed to answer.\n");
						sleep (TIMEOUT);
						redo;
					}
				}
				print STDERR "The order has been sent.\n";
			}
			print STDERR "All orders were sent\n";
			$sock->close();
			sleep (PERIOD_ORDER);
		}
		else
		{
			if (!$sock) { log_err("Can't open socket to send orders.\n"); }
			if (!$dbconn) { log_err("Can't connect to database to send orders.\n"); }
			sleep(TIMEOUT);
		}
	}
}

sub get_mask
{
	#print "Tread 2 on\n";
	my %config = @_;
	my $err;
	
	while (1)
	{
		my $sock;
		my $dbconn;
		my $message;

		($sock, $dbconn, $message) = init(%config);

		if ($sock && $dbconn)
		{
			while (1) 
			{
				$message->clear();
				$message->cmd(CMD_GMASK);
				eval 
				{
					$message->send();
				};
				if ($@) 
				{
					log_err("Failed to refresh mask while sending request.\n");
					sleep(TIMEOUT);
					redo;
				}
				$err = $message->recv();
				print STDERR "Mask received. err: $err CMD: ".$message->cmd()."\n";
				if(!$err && $message->cmd() == SUCCESS_CODE)
				{ 
					$dbconn->refresh_mask(split('\n', $message->data())); 
					last;
				} 
				else 
				{ 
					log_err("Failed to refresh mask while receiving answer.\n");
					sleep(TIMEOUT);
					redo;
				}
			}
			print STDERR "Mask refreshed\n";
			$sock->close();
			sleep (PERIOD_GMASK);
		}
		else
		{
			if (!$sock) { log_err("Can't open socket to refresh mask.\n"); }
			if (!$dbconn) { log_err("Can't connect to database to refresh mask.\n"); }
			sleep(TIMEOUT);
		}
	}

}

sub refresh_video
{
	#print "Tread 3 on\n";
	my %config = @_;
	my $sock;
	my $message;
	my $err;

	while (1)
	{
		$sock = new IO::Socket::INET(Proto => "tcp", PeerAddr => $config{"default.ip"}, PeerPort => $config{"default.port"});
		$message = new MessageStruct($config{"default.id"}, $sock, TIMEOUT);

		while ($sock)
		{
			while (1)
			{
				$message->clear();
				$message->cmd(CMD_VIDEO);
				$err = $message->send();
				if ($err)
				{
					log_err("Failed to update video.\n");
					redo;
				}
				$err = $message->recv();
				if (!$err && $message->cmd() == SUCCESS_CODE) 
				{
					last;
				}
				else
				{
					log_err("Failed to update video.\n");
					redo;
				}
			}

			$sock->close();
			#print "Video refreshed";
			sleep (PERIOD_VIDEO);
		}
		log_err("Can't open socket to update video.\n");
		sleep (TIMEOUT);
	}
}

sub log_err #($error_string)
{
	my $err = shift;
	open (F, '>>errors.log');
	flock (F, 2); #exclusive lock on file handle; object will be released at the end of the scope
	print F (strftime('%d.%m.%Y %H:%M:%S', localtime), " ", $err);
	close (F);
}

sub init #(config)
{
	my %config = @_;
	my $dbconn;
	my $message;
	my $sock;

	eval 
	{
		$sock = new IO::Socket::INET(Proto => "tcp", PeerAddr => $config{"default.ip"}, PeerPort => $config{"default.port"}) or die "$!";
	};
	if ($@) 
	{
		log_err($@);
		return (undef, undef, undef);
	}

	eval 
	{
		$message = new MessageStruct($config{"default.id"}, $sock, TIMEOUT);
	};
	if ($@) 
	{
		log_err($@);
		return (undef, undef, undef);
	}

	eval 
	{
		$dbconn = new DBConnection($config{"default.dbname"}, $config{"default.user"}, $config{"default.password"});
	};
	if ($@) 
	{
		log_err($@);
		return (undef, undef, undef);
	}

	return ($sock, $dbconn, $message);
}

1;

__END__