#!/usr/bin/perl

use Config::Simple;
use ThreadSubs;
use threads;
use strict;

$SIG{INT}=\&term;
sub term 
{
	print STDERR "\nClient stopped.\n";
	exit(0);
}

print "Client started\n";

my %config;
Config::Simple->import_from('config.cf', \%config);

#my $order_sender_thread = threads->create('ThreadSubs::send_orders', %config);
#$order_sender_thread->detach();

#my $mask_updater_thread = threads->create('ThreadSubs::get_mask', %config);
#$mask_updater_thread->detach();

#my $video_updater_thread = threads->create('ThreadSubs::refresh_video', %config);
#$video_updater_thread->detach();

threads->create(\&ThreadSubs::send_orders, %config)->detach();
threads->create(\&ThreadSubs::get_mask, %config)->detach();
#threads->create(\&ThreadSubs::refresh_video, %config)->detach();

while (1)
{
	sleep (1);
}

__END__
